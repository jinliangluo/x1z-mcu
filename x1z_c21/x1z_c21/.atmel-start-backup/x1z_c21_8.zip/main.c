#include <atmel_start.h>
#include "driver_examples.h"
#include "./driver/elog_drv.h"
#include "./driver/can_drv.h"
#include "headfile.h"

void adas_power_enable(void)
{
	gpio_set_pin_level(PIN_ADAS_POWER_EN, true);
	gpio_set_pin_direction(PIN_ADAS_POWER_EN, GPIO_DIRECTION_OUT);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	
	//TIMER_0_example();
	elog_init();
	timer_start(&TIMER_0);
	adas_power_enable();
	can_drv_init();
	wdt_set_timeout_period(&WDT_0, 1000, 4096);
	wdt_enable(&WDT_0);
	wdt_feed(&WDT_0);
	elog_test();
	//USART_O_register_callback();
	/* Replace with your application code */
	while (1) {
		wdt_feed(&WDT_0);
		elog_process();
		//time_process();
		//USART_0_example();	
		//USART_0_rcv_test();
	}
}
