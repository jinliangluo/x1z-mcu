/*
 * can_drv.c
 *
 * Created: 2018/10/3 18:17:37
 *  Author: Administrator
 */ 
#include <atmel_start.h>
#include <stdio.h>
#include "headfile.h"
#include "can_drv.h"
#include "elog_drv.h"

static void can_0_rx_callback(struct can_async_descriptor *const descr)
{
	struct can_message msg;
	uint8_t            data[64];
	char str[100];
	msg.data = data;
	can_async_read(descr, &msg);
	sprintf(str, "can0-rcv: id=0x%lX, dlc=%d, data=%02X %02X %02X %02X %02X %02X %02X %02X\r\n", msg.id, msg.len, msg.data[0], msg.data[1], msg.data[2], msg.data[3], msg.data[4], msg.data[5], msg.data[6], msg.data[7]);
	elog_print_string(str);
	return;
}


void can_drv_init(void)
{
	gpio_set_pin_level(PIN_CAN_MODE, false);	// �͵�ƽ��ʹ��CAN0
	gpio_set_pin_direction(PIN_CAN_MODE, GPIO_DIRECTION_OUT);
	
	can_async_register_callback(&CAN_0, CAN_ASYNC_RX_CB, (FUNC_PTR)can_0_rx_callback);
	
	can_async_enable(&CAN_0);
}