/*
 * can_drv.h
 *
 * Created: 2018/10/3 18:17:51
 *  Author: Administrator
 */ 


#ifndef CAN_DRV_H_
#define CAN_DRV_H_

#ifdef __cplusplus
extern "C" {
#endif

void can_drv_init(void);

#ifdef __cplusplus
}
#endif

#endif /* CAN_DRV_H_ */