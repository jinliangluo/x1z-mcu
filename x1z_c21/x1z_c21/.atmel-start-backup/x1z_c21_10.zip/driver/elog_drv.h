/*
 * elog_drv.h
 *
 * Created: 2018/9/30 21:04:11
 *  Author: Administrator
 */ 


#ifndef ELOG_DRV_H_
#define ELOG_DRV_H_


#ifdef __cplusplus
extern "C" {
#endif
	
	
struct elog_tx_type{
	struct elog_tx_type *next;
	int len;
	char *dat;
};

	
void elog_init(void);
void elog_process(void);
void elog_print_string(char *str);
void elog_test(void);


#ifdef __cplusplus
}
#endif	
	




#endif /* ELOG_DRV_H_ */