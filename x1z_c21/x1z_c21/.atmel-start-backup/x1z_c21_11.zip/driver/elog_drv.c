/*
 * elog_drv.c
 *
 * Created: 2018/9/30 21:02:11
 *  Author: ljl
 *   noted: ����SERCOM2��ELOG��������PCͨ�ţ����Է��ֲ����ʴ���230400ʱ�����ݽ��տ��ܻ��쳣���ʲ���������Ϊ240400��hpl_sercom_config.h��
 */ 
#include <string.h>
#include <malloc.h>
#include <stdio.h>
#include "elog_drv.h"
#include "driver_init.h"
#include "utils.h"



#define USART_RX_END_WORD			'$'
#define USART_RX_LENGTH				100
#define ELOG_ONLINE_TIME			1000*30	// 30S



static volatile uint8_t  elog_online_flag = 1;	// �������߱�ʶ����ʶ�Ƿ񽫴�ӡ��Ϣ���͸�pc��
static volatile uint32_t elog_rx_off = 0;	// ���ݽ���ƫ��λ��
static volatile uint8_t  elog_rx_buf[USART_RX_LENGTH];	// ���ݽ��ջ���
static volatile uint8_t  elog_tx_unfinish = 0;	// ��ʶ���д������ݴ�����

static struct elog_tx_type *pElog_head = NULL;

static struct timer_task elog_online_task;

static int32_t elog_keep_online_redelay(uint32_t delay);


static void elog_rx_deal(char *dat, uint32_t len)
{
	if (len <= 0)
	return;
	
	if ((elog_online_flag == 0) && (strstr(dat, "elogstart") != NULL))
	{
		elog_keep_online_redelay(ELOG_ONLINE_TIME);
		elog_online_flag = 1;
		elog_print_string("elog start\r\n");
		return;
	}
	if ((elog_online_flag != 0) && (strstr(dat, "elogstop") != NULL))
	{
		elog_print_string("elog stop\r\n");
		elog_online_flag = 0;
		return;
	}
}


static void elog_keep_online_cb(const struct timer_task *const timer_task)
{
	elog_online_flag = 0;
}


static void elog_tx_cb(const struct usart_async_descriptor *const descr)
{
	elog_tx_unfinish = 0;
}


static void elog_rx_cb(const struct usart_async_descriptor *const descr)
{
	uint32_t len = usart_async_is_tx_empty(&USART_0);
	if (len > 0)
	{
		if (len + elog_rx_off < USART_RX_LENGTH)
		{
			struct io_descriptor *io;
			usart_async_get_io_descriptor(&USART_0, &io);
			elog_rx_off += io_read(io, (uint8_t *)&elog_rx_buf[elog_rx_off], len);
		}
	}
}


static int32_t elog_keep_online_redelay(uint32_t delay)
{
	if (delay == 0)
		return ERR_INVALID_DATA;
	
	timer_remove_task(&TIMER_0, &elog_online_task);
	
	elog_online_task.mode = TIMER_TASK_ONE_SHOT;
	elog_online_task.interval = delay;
	elog_online_task.cb = elog_keep_online_cb;
	return timer_add_task(&TIMER_0, &elog_online_task);
}

static void elog_tx_fifo_add(struct elog_tx_type *node)
{
	struct elog_tx_type *ptmp;
	if (node == NULL)
		return;
	
	node->next = NULL;
	if (pElog_head == NULL)
	{	
		pElog_head = node;
		return;
	}
	ptmp = pElog_head;
	while (ptmp->next != NULL)
		ptmp = ptmp->next;
	ptmp->next = node;
	return;
}

static void elog_tx_fifo_remove(void)
{
	if (pElog_head == NULL)
		return;
	struct elog_tx_type *ptmp = pElog_head;
	
	pElog_head = pElog_head->next;

	free(ptmp);
}


static uint32_t elog_write(char *dat, uint32_t len)
{
	struct elog_tx_type *prt = malloc(sizeof(struct elog_tx_type) + len);
	if (prt == NULL)
		return 0;
	
	prt->next = NULL;
	prt->len = len;
	prt->dat = (char *)((char *)prt + sizeof(struct elog_tx_type));
	memcpy(prt->dat, dat, len);
	elog_tx_fifo_add(prt);
	return len;
}


void elog_print_string(char *str)
{
	if (str == NULL)
		return;
	if (elog_online_flag)
		elog_write(str, strlen(str));
}


static void elog_test_send(const struct timer_task *const timer_task)
{
	static uint8_t cnt = 0;
	char str[30];
	sprintf(str, "elog: %d\r\n", ++cnt);
	elog_print_string(str);
	//struct io_descriptor *io;
	//usart_async_get_io_descriptor(&USART_0, &io);
	//io_write(io, (uint8_t *)str, strlen(str));
	
}

void elog_test(void)
{
	static struct timer_task elog_send;
	
	elog_send.interval = 5000;
	elog_send.cb = elog_test_send;
	elog_send.mode = TIMER_TASK_REPEAT;
	timer_add_task(&TIMER_0, &elog_send);
}

void elog_process(void)
{
	// ���Ͳ���
	CRITICAL_SECTION_ENTER();
	if (pElog_head != NULL && elog_tx_unfinish == 0)
	{
		struct io_descriptor *io;
		usart_async_get_io_descriptor(&USART_0, &io);
		elog_tx_unfinish = 1;
		io_write(io, (uint8_t *)(pElog_head->dat), pElog_head->len);
		elog_tx_fifo_remove();
	}
	CRITICAL_SECTION_LEAVE();
	
	// ���ղ���
	char rcvbuf[USART_RX_LENGTH + 1];
	uint16_t i, deallen = 0;
	
	CRITICAL_SECTION_ENTER();
	if (elog_rx_off != 0)
	{
		deallen = elog_rx_off;
		memcpy(rcvbuf, (char*)elog_rx_buf, deallen);
	}
	CRITICAL_SECTION_LEAVE();
	rcvbuf[deallen] = '\0';
	for (i = 0; i < deallen; i++)
	{
		if (rcvbuf[i] == USART_RX_END_WORD || rcvbuf[i] == '\n')
		{
			CRITICAL_SECTION_ENTER();
			elog_rx_off = 0;
			CRITICAL_SECTION_LEAVE();
			elog_rx_deal(rcvbuf, deallen);
			break;
		}
	}	
}

void elog_init(void)
{
	struct io_descriptor *io;
	
	usart_async_get_io_descriptor(&USART_0, &io);
	usart_async_register_callback(&USART_0, USART_ASYNC_RXC_CB, elog_rx_cb);
	usart_async_register_callback(&USART_0, USART_ASYNC_TXC_CB, elog_tx_cb);
	usart_async_enable(&USART_0);
}
